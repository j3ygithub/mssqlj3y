from secret.mssqlj3y.settings import DEBUG
on_linux = True

if DEBUG and on_linux:
    login_info = {
        "driver": "{ODBC Driver 17 for SQL Server}",
        "server": "tcp:150.117.123.35",
        "database": "mail_job",
        "uid": "jimmy_lin",
        "pwd": "Chief+26576688@",
    }
elif DEBUG and not on_linux:
    login_info = {
        "driver": "{SQL Server}",
        "server": "tcp:150.117.123.35",
        "database": "mail_job",
        "uid": "jimmy_lin",
        "pwd": "Chief+26576688@",
    }
elif not DEBUG and on_linux:
    login_info = {
        "driver": "{ODBC Driver 17 for SQL Server}",
        "server": "tcp:10.210.31.15",
        "database": "mail_job",
        "uid": "jimmy_lin",
        "pwd": "Chief+26576688@",
    }
elif not DEBUG and not on_linux:
    login_info = {
        "driver": "{SQL Server}",
        "server": "tcp:10.210.31.15",
        "database": "mail_job",
        "uid": "jimmy_lin",
        "pwd": "Chief+26576688@",
    }
