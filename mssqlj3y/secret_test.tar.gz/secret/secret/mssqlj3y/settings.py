import os


# DEBUG
DEBUG = False

# datebase for Django
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'mssqlj3ydb',
        'USER': 'admin',
        'PASSWORD': '20180105',
        'HOST': '10.210.201.12',
        'PORT': '3306',
    }
}

# smtp things

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
USE_GMAIL = False

if USE_GMAIL:
    EMAIL_HOST = 'smtp.gmail.com'
    EMAIL_USE_TLS = True
    EMAIL_PORT = 587
    EMAIL_HOST_USER = 'j3ycode@gmail.com'
    EMAIL_HOST_PASSWORD = 'j3ycode46wj6'
    DEFAULT_FROM_EMAIL = 'Mail Job <j3ycode@gmail.com>'
    SERVER_EMAIL = 'Mail Job <j3ycode@gmail.com>'
else:
    EMAIL_HOST = '223.26.68.17'
    EMAIL_USE_TLS = False
    EMAIL_PORT = 25
    EMAIL_HOST_USER = ''
    EMAIL_HOST_PASSWORD = ''
    DEFAULT_FROM_EMAIL = 'Mail Job <reminder@chief.com.tw>'
    SERVER_EMAIL = 'Mail Job <reminder@chief.com.tw>'
